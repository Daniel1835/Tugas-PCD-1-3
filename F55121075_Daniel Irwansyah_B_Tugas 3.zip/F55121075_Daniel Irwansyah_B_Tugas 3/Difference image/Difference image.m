img1 = imread('1.jpg');
img2 = imread('2.jpg');

[rows,cols,channels] = size(img1);
img2 = imresize(img2, [rows cols]);

img1_gray = rgb2gray(img1);
img2_gray = rgb2gray(img2);

diff_img = imabsdiff(img1_gray, img2_gray);

imshow(diff_img);
title('Perbedaan antara Gambar 1 dan Gambar 2');

imwrite(diff_img, 'perbedaan.jpg');
