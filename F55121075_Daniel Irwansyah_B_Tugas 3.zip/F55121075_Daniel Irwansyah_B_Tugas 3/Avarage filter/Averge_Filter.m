img = imread('1.jpg');
img_gray = rgb2gray(img);
kernel_size = 5;
kernel = fspecial('average', kernel_size);
filtered_img = imfilter(img_gray, kernel);
imshow(filtered_img);
title('Hasil Average Filter');
% Simpan citra hasil operasi average filter
imwrite(filtered_img, 'hasil_average_filter.jpg');
